/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package easykanban;
import org.junit.Test;
import static org.junit.Assert.*;

public class EasyKanbanTests {

    
    @Test //(geeksforgeeks,2024)
    public void testUsernameCorrectlyFormatted() {
        Login newUser = new Login("kyl_1", "Password1!", "Kyle", "Smith");
        assertTrue(newUser.checkUserName());
    }

    @Test //(geeksforgeeks,2024)
    public void testUsernameIncorrectlyFormatted() {
        Login newUser = new Login("kyle!!!!!!!", "Password1!", "Kyle", "Smith");
        assertFalse(newUser.checkUserName());
    }

    @Test //(geeksforgeeks,2024)
    public void testPasswordMeetsComplexityRequirements() {
        Login newUser = new Login("kyl_1", "Ch&&sec@ke99!", "Kyle", "Smith");
        assertTrue(newUser.checkPasswordComplexity());
    }

    @Test //(geeksforgeeks,2024)
    public void testPasswordDoesNotMeetComplexityRequirements() {
        Login newUser = new Login("kyl_1", "password", "Kyle", "Smith");
        assertFalse(newUser.checkPasswordComplexity());
    }

    
    @Test //(geeksforgeeks,2024)
    public void testTaskDescriptionLengthSuccess() {
        Task newTask = new Task("Login Feature", "Create Login to authenticate users", "Robyn", "Harrison", 8, "To Do", 1);
        assertTrue(newTask.checkTaskDescription());
    }

    @Test //(geeksforgeeks,2024)
    public void testTaskDescriptionLengthFailure() {
        Task newTask = new Task("Login Feature", "This is a very long task description that exceeds the maximum allowed characters.", "Robyn", "Harrison", 8, "To Do", 1);
        assertFalse(newTask.checkTaskDescription());
    }

   

   
    @Test //(geeksforgeeks,2024)
    public void testTaskIDFormat() {
        Task newTask = new Task("Login Feature", "Create Login to authenticate users", "Robyn", "Harrison", 8, "To Do", 1);
        assertEquals("AD:1:HAR", newTask.createTaskID());
    }

   
    @Test//(geeksforgeeks,2024)
    public void testTotalHoursCalculation() {
        Task[] tasks = {
            new Task("Login Feature", "Create Login to authenticate users", "Robyn", "Harrison", 8, "To Do", 1),
            new Task("Add Task Feature", "Create Add Task feature to add task users", "Mike", "Smith", 10, "Doing", 2),
            new Task("Create Reports", "Create reports for task tracking", "Samantha", "Paulson", 2, "Done", 3),
            new Task("Add Arrays", "Add arrays for efficient data storage", "Glenda", "Oberholzer", 11, "To Do", 4)
        };

        int totalHours = 0;
        for (Task task : tasks) {
            totalHours += task.getTaskDuration();
        }

        assertEquals(31, totalHours);
    }

    
    @Test //(geeksforgeeks,2024)
    public void testDeveloperArrayPopulated() {
        Task[] tasks = {
            new Task("Login Feature", "Create Login to authenticate users", "Robyn", "Harrison", 8, "To Do", 1),
            new Task("Add Task Feature", "Create Add Task feature to add task users", "Mike", "Smith", 10, "Doing", 2),
            new Task("Create Reports", "Create reports for task tracking", "Samantha", "Paulson", 2, "Done", 3),
            new Task("Add Arrays", "Add arrays for efficient data storage", "Glenda", "Oberholzer", 11, "To Do", 4)
        };

        String[] expectedDevelopers = {"Robyn Harrison", "Mike Smith", "Samantha Paulson", "Glenda Oberholzer"};
        String[] actualDevelopers = new String[tasks.length];

        for (int i = 0; i < tasks.length; i++) {
            actualDevelopers[i] = tasks[i].getDeveloperName();
        }

        assertArrayEquals(expectedDevelopers, actualDevelopers);
    }

    
    @Test //(geeksforgeeks,2024)
    public void testDisplayTaskWithLongestDuration() {
        Task[] tasks = {
            new Task("Login Feature", "Create Login to authenticate users", "Robyn", "Harrison", 8, "To Do", 1),
            new Task("Add Task Feature", "Create Add Task feature to add task users", "Mike", "Smith", 10, "Doing", 2),
            new Task("Create Reports", "Create reports for task tracking", "Samantha", "Paulson", 2, "Done", 3),
            new Task("Add Arrays", "Add arrays for efficient data storage", "Glenda", "Oberholzer", 11, "To Do", 4)
        };

        Task longestTask = tasks[0];
        for (Task task : tasks) {
            if (task.getTaskDuration() > longestTask.getTaskDuration()) {
                longestTask = task;
            }
        }

        assertEquals("Glenda Oberholzer, 11", longestTask.getDeveloperName() + ", " + longestTask.getTaskDuration());
    }

    
    @Test //(geeksforgeeks,2024)
    public void testSearchTaskByName() {
        Task[] tasks = {
            new Task("Login Feature", "Create Login to authenticate users", "Robyn", "Harrison", 8, "To Do", 1),
            new Task("Add Task Feature", "Create Add Task feature to add task users", "Mike", "Smith", 10, "Doing", 2),
            new Task("Create Reports", "Create reports for task tracking", "Samantha", "Paulson", 2, "Done", 3),
            new Task("Add Arrays", "Add arrays for efficient data storage", "Glenda", "Oberholzer", 11, "To Do", 4)
        };

        String taskNameToSearch = "Create Reports";
        boolean found = false;
        for (Task task : tasks) {
            if (task.getTaskName().equals(taskNameToSearch)) {
                assertEquals("Samantha Paulson, Create Reports", task.getDeveloperName() + ", " + task.getTaskName());
                found = true;
                break;
            }
        }

        assertTrue(found);
    }

    
    @Test //(geeksforgeeks,2024)
    public void testDeleteTaskByName() {
        Task[] tasks = {
            new Task("Login Feature", "Create Login to authenticate users", "Robyn", "Harrison", 8, "To Do", 1),
            new Task("Add Task Feature", "Create Add Task feature to add task users", "Mike", "Smith", 10, "Doing", 2),
            new Task("Create Reports", "Create reports for task tracking", "Samantha", "Paulson", 2, "Done", 3),
            new Task("Add Arrays", "Add arrays for efficient data storage", "Glenda", "Oberholzer", 11, "To Do", 4)
        };

        String taskNameToDelete = "Create Reports";
        int initialSize = tasks.length;

        for (Task task : tasks) {
            if (task.getTaskName().equals(taskNameToDelete)) {
                tasks = removeTask(tasks, task);
                break;
            }
        }

        assertEquals(initialSize - 1, tasks.length);
    }

    
    private Task[] removeTask(Task[] tasks, Task taskToRemove) {
        Task[] result = new Task[tasks.length - 1];
        int index = 0;
        for (Task task : tasks) {
            if (!task.equals(taskToRemove)) {
                result[index++] = task;
            }
        }
        return result;
    }
}

/* CODE ATTRIBUTES
the refernece used in this unit test is mrs Fatimas video
//https://youtu.be/sFTbCVnUbLo?si=_5laLjZNENT4XAyj
geeksforgeeks, 2024, unit testiong from: https://www.geeksforgeeks.org/unit-testing-software-testing/
*/