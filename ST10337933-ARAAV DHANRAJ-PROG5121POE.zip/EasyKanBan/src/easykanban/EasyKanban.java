/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package easykanban;

import javax.swing.*;  // Importing necessary classes from javax.swing package
import java.util.ArrayList;  // Importing necessary classes from java.util package
import java.util.List;
import java.util.regex.Pattern;

public class EasyKanban {
    // List to store registered users and tasks
    private static final List<Login> users = new ArrayList<>();  // ArrayList to store Login objects
    private static final List<Task> tasks = new ArrayList<>();   // ArrayList to store Task objects

    public static void main(String[] args) {
        boolean exit = false;  // Flag to control main loop

        // Main application loop
        while (!exit) {
            // Options presented to the user in the main menu
            String[] options = {"Register", "Login", "Quit"};
            int choice = JOptionPane.showOptionDialog(null, "Welcome to EasyKanban", "Main Menu", //(javatpoint,N/A)
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]); //(javatpoint,N/A)

            // Switch statement based on user's choice in the main menu
            switch (choice) {
                case 0 -> register();  // If user chooses "Register", call register() method
                case 1 -> {
                    if (login()) {  // If user successfully logs in
                        taskMenu();  // Call taskMenu() to display task-related options
                    }
                }
                case 2 -> exit = true;  // If user chooses "Quit", exit the main loop
                default -> JOptionPane.showMessageDialog(null, "Invalid choice, please try again.");  // Display error message for invalid choices
            }
        }
    }

    // Method to handle user registration
    private static void register() {
        String username = JOptionPane.showInputDialog("Enter username:");  //(javatpoint,N/A) // Prompt user for username
        String password = JOptionPane.showInputDialog("Enter password:");  //(javatpoint,N/A) // Prompt user for password
        String firstName = JOptionPane.showInputDialog("Enter first name:");   //(javatpoint,N/A) // Prompt user for first name
        String lastName = JOptionPane.showInputDialog("Enter last name:");   //(javatpoint,N/A) // Prompt user for last name

        // Create a new Login object with provided user details
        Login newUser = new Login(username, password, firstName, lastName);
        String registrationMessage = newUser.registerUser();  // Attempt to register the user
        JOptionPane.showMessageDialog(null, registrationMessage); //(javatpoint,N/A) // Display registration message to user

        // If username and password meet criteria, add user to list of registered users
        if (newUser.checkUserName() && newUser.checkPasswordComplexity()) {
            users.add(newUser);
        }
    }

    // Method to handle user login
    private static boolean login() {
        String username = JOptionPane.showInputDialog("Enter username:"); //(javatpoint,N/A) // Prompt user for username
        String password = JOptionPane.showInputDialog("Enter password:"); //(javatpoint,N/A)  // Prompt user for password

        // Loop through registered users to find a match for entered credentials
        for (Login user : users) {
            String loginStatus = user.returnLoginStatus(username, password);  // Check if username and password match
            JOptionPane.showMessageDialog(null, loginStatus);  //(javatpoint,N/A) // Display login status message to user

            // If login is successful, return true
            if (loginStatus.startsWith("Welcome")) {
                return true;
            }
        }
        return false;  // If no match is found, return false
    }

    // Method to display task management menu
    private static void taskMenu() {
        boolean exit = false;  // Flag to control task menu loop

        // Task management menu loop
        while (!exit) {
            // Options presented to the user in the task menu
            String[] options = {"Add tasks", "Show report", "Display tasks by status", "Display task with longest duration", "Search task by name", "Search tasks by developer", "Delete task by name", "Display all tasks", "Quit"};
            int choice = JOptionPane.showOptionDialog(null, "Task Menu", "Task Menu", //(javatpoint,N/A)
                    
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]); //(javatpoint,N/A)

            // Switch statement based on user's choice in the task menu
            switch (choice) {
                case 0 -> addTasks();  // If user chooses "Add tasks", call addTasks() method
                case 1 -> JOptionPane.showMessageDialog(null, "Coming Soon");  // Placeholder for future functionality
                case 2 -> displayTasksByStatus("Done");  // If user chooses "Display tasks by status", call displayTasksByStatus() with status "Done"
                case 3 -> displayTaskWithLongestDuration();  // If user chooses "Display task with longest duration", call displayTaskWithLongestDuration()
                case 4 -> searchTaskByName();  // If user chooses "Search task by name", call searchTaskByName()
                case 5 -> searchTasksByDeveloper();  // If user chooses "Search tasks by developer", call searchTasksByDeveloper()
                case 6 -> deleteTaskByName();  // If user chooses "Delete task by name", call deleteTaskByName()
                case 7 -> displayAllTasks();  // If user chooses "Display all tasks", call displayAllTasks()
                case 8 -> exit = true;  // If user chooses "Quit", exit the task menu loop
                default -> JOptionPane.showMessageDialog(null, "Invalid choice, please try again.");  // Display error message for invalid choices
            }
        }
    }

    // Method to add tasks to the task list
    private static void addTasks() {
        int numberOfTasks = Integer.parseInt(JOptionPane.showInputDialog("How many tasks would you like to add?"));  // Prompt user for number of tasks to add

        // Loop to add specified number of tasks
        for (int i = 0; i < numberOfTasks; i++) {
            // Prompt user for task details
            String taskName = JOptionPane.showInputDialog("Enter task name:"); //(javatpoint,N/A)
            String taskDescription = JOptionPane.showInputDialog("Enter task description:"); //(javatpoint,N/A)
            String developerFirstName = JOptionPane.showInputDialog("Enter developer first name:"); //(javatpoint,N/A)
            String developerLastName = JOptionPane.showInputDialog("Enter developer last name:"); //(javatpoint,N/A)
            int taskDuration = Integer.parseInt(JOptionPane.showInputDialog("Enter task duration in hours:")); //(javatpoint,N/A)
            String taskStatus = JOptionPane.showInputDialog("Enter task status (To Do, Done, Doing):"); //(javatpoint,N/A)

            // Create a new Task object with provided task details
            Task newTask = new Task(taskName, taskDescription, developerFirstName, developerLastName, taskDuration, taskStatus, tasks.size());

            // Validate task description length
            if (newTask.checkTaskDescription()) {
                tasks.add(newTask);  // Add task to list of tasks
                JOptionPane.showMessageDialog(null, "Task successfully captured"); //(javatpoint,N/A)  // Display success message to user
            } else {
                JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters");  //(javatpoint,N/A) // Display error message for invalid task description length
            }
        }

        // Calculate and display total hours across all tasks
        int totalHours = tasks.stream().mapToInt(Task::returnTotalHours).sum();
        JOptionPane.showMessageDialog(null, "Total hours across all tasks: " + totalHours); //(javatpoint,N/A)
    }

    // Method to display tasks by specified status
    private static void displayTasksByStatus(String status) {
        StringBuilder message = new StringBuilder();

        
        
        
        // Loop through tasks and append details of tasks with specified status to message
        for (Task task : tasks) {
            if (task.getTaskStatus().equalsIgnoreCase(status)) {
                message.append("Developer: ").append(task.getDeveloperName())
                        .append(", Task Name: ").append(task.getTaskName())
                        .append(", Task Duration: ").append(task.getTaskDuration())
                        .append("\n");
            }
        }
        JOptionPane.showMessageDialog(null, message.toString());  // Display tasks with specified status to user //(javatpoint,N/A)
    }

    
    
    
    
    // Method to display task with longest duration
    private static void displayTaskWithLongestDuration() {
        // Find task with longest duration using stream and max operation
        Task longestTask = tasks.stream().max((task1, task2) -> Integer.compare(task1.getTaskDuration(), task2.getTaskDuration())).orElse(null);

        // If longestTask is not null, display details of task with longest duration; otherwise, display "No tasks found."
        if (longestTask != null) {
            JOptionPane.showMessageDialog(null, "Developer: " + longestTask.getDeveloperName() + ", Task Duration: " + longestTask.getTaskDuration()); //(javatpoint,N/A)
        } else {
            JOptionPane.showMessageDialog(null, "No tasks found."); //(javatpoint,N/A)
        }
    }

    // Method to search for task by name
    private static void searchTaskByName() {
        String taskName = JOptionPane.showInputDialog("Enter task name to search:");  // Prompt user for task name to search

        // Loop through tasks to find task with specified name and display details to user
        for (Task task : tasks) {
            if (task.getTaskName().equalsIgnoreCase(taskName)) {
                JOptionPane.showMessageDialog(null, "Task Name: " + task.getTaskName() + ", Developer: " + task.getDeveloperName() + ", Task Status: " + task.getTaskStatus());
                return;
                //(javatpoint,N/A)
            }
        }
        JOptionPane.showMessageDialog(null, "Task not found.");  // Display message if task with specified name is not found
    }//(javatpoint,N/A)

    
    
    // Method to search for tasks by developer name
    private static void searchTasksByDeveloper() {
        String developerName = JOptionPane.showInputDialog("Enter developer name to search:");  // Prompt user for developer name to search
        StringBuilder message = new StringBuilder();

        
        
        
        
        // Loop through tasks to find tasks assigned to specified developer and append details to message
        for (Task task : tasks) {
            if (task.getDeveloperName().equalsIgnoreCase(developerName)) {
                message.append("Task Name: ").append(task.getTaskName())
                        .append(", Task Status: ").append(task.getTaskStatus())
                        .append("\n");
            }
        }
        JOptionPane.showMessageDialog(null, message.toString());  // Display tasks assigned to specified developer to user
    }

    // Method to delete task by name
    private static void deleteTaskByName()
    
    {
        String taskName = JOptionPane.showInputDialog("Enter task name to delete:");  // Prompt user for task name to delete
        tasks.removeIf(task -> task.getTaskName().equalsIgnoreCase(taskName));  // Remove task with specified name from list of tasks
        JOptionPane.showMessageDialog(null, "Task deleted successfully.");  // Display success message to user
    }

    
    
    
    // Method to display details of all tasks
    private static void displayAllTasks() {
        StringBuilder message = new StringBuilder();

        // Loop through tasks and append details of each task to message
        for (Task task : tasks) {
            message.append(task.printTaskDetails()).append("\n\n");
        }
        JOptionPane.showMessageDialog(null, message.toString());  // Display details of all tasks to user
    }
}

// Class representing a user login
class Login {
    private final String username;  // Instance variable to store username
    private final String password;  // Instance variable to store password
    private final String firstName;  // Instance variable to store first name
    private final String lastName;  // Instance variable to store last name

    // Constructor to initialize Login object with provided user details
    public Login(String username, String password, String firstName, String lastName) {
        
        
        this.username = username;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    
    
    
    // Method to validate username format
    public boolean checkUserName() {
        
        
        
        
        return username.matches("^[a-zA-Z0-9_]{1,5}$") && username.contains("_");  // Validate username against specified pattern
    }

    // Method to validate password complexity
    public boolean checkPasswordComplexity() {
        
        
        
        String passwordPattern = "^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*]).{8,}$";  // Define password pattern using regular expression
        return Pattern.matches(passwordPattern, password);  // Validate password against specified pattern
    }

    // Method to register user and return registration status message
    public String registerUser() {
        if (!checkUserName()) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.";
        } else if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.";
        }
        return "User registered successfully";  // Return success message if user registration is successful
    }

    // Method to validate user login credentials
    public boolean loginUser(String enteredUsername, String enteredPassword) {
        
        
        return this.username.equals(enteredUsername) && this.password.equals(enteredPassword);  // Check if entered credentials match stored credentials
    }

    
    
    
    
    // Method to return login status message based on entered credentials
    public String returnLoginStatus(String enteredUsername, String enteredPassword) {
        if (loginUser(enteredUsername, enteredPassword)) {
            
            
            
            return "Welcome " + firstName + " " + lastName + ", it is great to see you again.";  // Return welcome message if login is successful
        } else {
            
            
            
            
            return "Username or password incorrect, please try again";  // Return error message if login is unsuccessful
        }
    }
}




// Class representing a task
final class Task {
    
    private final String taskName; 
    // Instance variable to store task name
    private final String taskDescription;
    
// Instance variable to store task description
    private final String developerFirstName;
    
// Instance variable to store developer's first name
    private final String developerLastName;  // Instance variable to store developer's last name
    private final int taskDuration;  
// Instance variable to store task duration in hours
    private final String taskStatus;  



// Instance variable to store task status
    private final int taskNumber;  
// Instance variable to store task number
    private final String taskID;  // Instance variable to store task ID

    // initialize Task object with provided task details
    public Task(String taskName, String taskDescription, String developerFirstName, String developerLastName, int taskDuration, String taskStatus, int taskNumber) {
        this.taskName = taskName;
        
        this.taskDescription = taskDescription;
        
        this.developerFirstName = developerFirstName;
        
        this.developerLastName = developerLastName;
        
        this.taskDuration = taskDuration;
        
        
        this.taskStatus = taskStatus;
        
        this.taskNumber = taskNumber;
        this.taskID = createTaskID();  // Generate task ID based on provided task details
    }

    // M validate task description length
    public boolean checkTaskDescription() {
        
        return taskDescription.length() <= 50;  // Validate task description length
    }

    // generate task ID based on task details
    public String createTaskID() {
        
        return (taskName.substring(0, 2) + ":" + taskNumber + ":" + developerLastName.substring(developerLastName.length() - 3)).toUpperCase();  // Generate and return task ID
    }

    //  return formatted task details
    public String printTaskDetails() {
        
        return "Task Status: " + taskStatus + "\nDeveloper Details: " + developerFirstName + " " + developerLastName + "\nTask Number: " + taskNumber + "\nTask Name: " + taskName + "\nTask Description: " + taskDescription + "\nTask ID: " + taskID + "\nTask Duration: " + taskDuration + " hours";  // Return formatted task details
    }

    
    
    // return task duration in hours
    
    
    public int returnTotalHours() {
        
        return taskDuration;  // Return task duration
    }

    //  retrieve task status
    
    
    public String getTaskStatus() {
        
        return taskStatus;  // Return task status
    }

    // retrieve developer's full name
    
    
    public String getDeveloperName() {
        
        return developerFirstName + " " + developerLastName;  // Return developer's full name
    }

    //  retrieve task name
    
    public String getTaskName() {
        
        
        return taskName;  // Return task name
    }

    
    //retrieve task duration in hours
    public int getTaskDuration() {
        
        
        return taskDuration;  // Return task duration
    }
}


/* CODE ATTRIBUTIONS
Java Regular expressions, w3scools, 1998, from: https://www.w3schools.com/java/java_regex.asp
Java Boolean, w3schools, 1998, from: https://www.w3schools.com/java/java_booleans.asp
JOption, javatpoint, N/A from: https://www.javatpoint.com/java-joptionpane

*/